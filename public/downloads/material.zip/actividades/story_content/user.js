function ExecuteScript(strId)
{
  switch (strId)
  {
      case "69OAaVlrMmR":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

